{{/*
Expand the name of the chart.
*/}}
{{- define "firstresponse.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "firstresponse.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart label value.
*/}}
{{- define "firstresponse.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "firstresponse.labels" -}}
helm.sh/chart: {{ include "firstresponse.chart" . }}
{{ include "firstresponse.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "firstresponse.selectorLabels" -}}
app.kubernetes.io/name: {{ include "firstresponse.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Backend selector labels
*/}}
{{- define "firstresponse.backend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "firstresponse.name" . }}-backend
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Frontend selector labels
*/}}
{{- define "firstresponse.frontend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "firstresponse.name" . }}-frontend
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use.
*/}}
{{- define "firstresponse.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "firstresponse.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Fully qualified PostgreSQL hostname (embedded or external).
*/}}
{{- define "firstresponse.postgresHost" -}}
{{- if .Values.postgresql.enabled }}
{{- printf "%s-postgresql" (include "firstresponse.fullname" .) }}
{{- else }}
{{- required "externalDatabase.host is required when postgresql.enabled=false" .Values.externalDatabase.host }}
{{- end }}
{{- end }}

{{/*
PostgreSQL port.
*/}}
{{- define "firstresponse.postgresPort" -}}
{{- if .Values.postgresql.enabled }}5432
{{- else }}{{- .Values.externalDatabase.port | default 5432 }}
{{- end }}
{{- end }}

{{/*
PostgreSQL database name.
*/}}
{{- define "firstresponse.postgresDatabase" -}}
{{- if .Values.postgresql.enabled }}
{{- .Values.postgresql.auth.database }}
{{- else }}
{{- .Values.externalDatabase.database }}
{{- end }}
{{- end }}

{{/*
PostgreSQL username.
*/}}
{{- define "firstresponse.postgresUser" -}}
{{- if .Values.postgresql.enabled }}
{{- .Values.postgresql.auth.username }}
{{- else }}
{{- .Values.externalDatabase.user }}
{{- end }}
{{- end }}

{{/*
Fully qualified Redis hostname (embedded or external).
*/}}
{{- define "firstresponse.redisHost" -}}
{{- if .Values.redis.enabled }}
{{- printf "%s-redis-master" (include "firstresponse.fullname" .) }}
{{- else }}
{{- required "externalRedis.host is required when redis.enabled=false" .Values.externalRedis.host }}
{{- end }}
{{- end }}

{{/*
Redis port.
*/}}
{{- define "firstresponse.redisPort" -}}
{{- if .Values.redis.enabled }}6379
{{- else }}{{- .Values.externalRedis.port | default 6379 }}
{{- end }}
{{- end }}

{{/*
Name of the Secret containing database credentials.
*/}}
{{- define "firstresponse.databaseSecretName" -}}
{{- if .Values.postgresql.enabled }}
{{- printf "%s-postgresql" (include "firstresponse.fullname" .) }}
{{- else if .Values.externalDatabase.existingSecret }}
{{- .Values.externalDatabase.existingSecret }}
{{- else }}
{{- printf "%s-external-db" (include "firstresponse.fullname" .) }}
{{- end }}
{{- end }}

{{/*
Image pull secrets — merges .Values.imagePullSecrets with the Replicated
enterprise-pull-secret when global.replicated.dockerconfigjson is present.
*/}}
{{- define "firstresponse.imagePullSecrets" -}}
{{- $secrets := list -}}
{{- if .Values.imagePullSecrets -}}
  {{- range .Values.imagePullSecrets -}}
    {{- $secrets = append $secrets . -}}
  {{- end -}}
{{- end -}}
{{- if and .Values.global .Values.global.replicated .Values.global.replicated.dockerconfigjson -}}
  {{- $secrets = append $secrets (dict "name" "enterprise-pull-secret") -}}
{{- end -}}
{{- if $secrets }}
imagePullSecrets:
  {{- toYaml $secrets | nindent 2 }}
{{- end -}}
{{- end -}}

{{/*
Name of the Secret containing Redis credentials.
*/}}
{{- define "firstresponse.redisSecretName" -}}
{{- if .Values.redis.enabled }}
{{- printf "%s-redis" (include "firstresponse.fullname" .) }}
{{- else if .Values.externalRedis.existingSecret }}
{{- .Values.externalRedis.existingSecret }}
{{- else }}
{{- printf "%s-external-redis" (include "firstresponse.fullname" .) }}
{{- end }}
{{- end }}
